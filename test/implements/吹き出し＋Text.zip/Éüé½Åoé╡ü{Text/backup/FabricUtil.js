function isSpeechBubbleSVG(obj){
  if (obj && obj.customType && obj.customType==='speechBubbleSVG') {
    return true;
  }
  return false;
}
function isSpeechBubbleText(obj){
  if (obj && obj.customType && obj.customType==='speechBubbleText') {
    return true;
  }
  return false;
}

function getRectTargetObject(obj){
  const targetObj = obj.targetObject;
  const rect = canvas.getObjects().find(obj => obj.type === 'rect' && obj.targetObject === targetObj);
  return rect;
}

function isText(activeObject) {
  return (activeObject && (activeObject.type === 'i-text' || activeObject.type === "text" ||
     activeObject.type === "textbox" || activeObject.type === "vertical-textbox"));
}

function isVerticalText(activeObject) {
  let result = (activeObject && (activeObject.type === "vertical-textbox"));
  return result;
}

function isHorizontalText(activeObject) {
  let result =  (activeObject && (activeObject.type === 'i-text' || activeObject.type === "text" || activeObject.type === "textbox"));
  return result;
}


function generateGUID() {
  const array = new Uint8Array(16);
  window.crypto.getRandomValues(array);
  array[6] = (array[6] & 0x0f) | 0x40;
  array[8] = (array[8] & 0x3f) | 0x80;
  const guid = Array.from(array).map(b => ('00' + b.toString(16)).slice(-2)).join('');
  return `${guid.slice(0, 8)}-${guid.slice(8, 12)}-${guid.slice(12, 16)}-${guid.slice(16, 20)}-${guid.slice(20)}`;
}


function setGUID(personObject, childObject) {
  if (!personObject.guids) {
    personObject.guids = [];
  }
  guid = getGUID(childObject);
  personObject.guids.push(guid);
}


function getGUID(activeObject) {
  if (!activeObject) {
    return null;
  }

  if (activeObject.guid) {
    return activeObject.guid;
  }
  let guid = generateGUID();
  activeObject.guid = guid;
  return guid;
}
